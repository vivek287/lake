<?php debug_backtrace() || die ("Direct access not permitted"); ?>
